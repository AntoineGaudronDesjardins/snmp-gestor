#!/bin/bash
stat -c '%s' /etc/shadow
