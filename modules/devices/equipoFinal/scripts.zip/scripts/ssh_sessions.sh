#!/bin/bash
num_sessions=$(who | grep -c 'pts/.*')
echo $num_sessions
